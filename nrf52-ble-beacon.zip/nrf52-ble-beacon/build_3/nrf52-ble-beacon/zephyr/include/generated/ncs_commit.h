#ifndef _NCS_COMMIT_H_
#define _NCS_COMMIT_H_

/*  values come from cmake/version.cmake
 * BUILD_COMMIT related  values will be 'git rev-parse',
 * alternatively user defined BUILD_VERSION.
 */

#define NCS_COMMIT                   89ba1294ac9b
#define NCS_COMMIT_STRING            "89ba1294ac9b"

#endif /* _NCS_COMMIT_H_ */
