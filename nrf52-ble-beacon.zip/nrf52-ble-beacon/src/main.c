/*
 * BLE Peripheral with Nordic UART Service (NUS)
 * - Phone (nRF Connect / LightBlue) sends text.
 * - If it sends "1" -> onboard LED blinks.
 *   If it sends "0" -> LED stops (off).
 * - Echoes any received text back to the phone.
 * - Still prints to USB/Putty.
 */

#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/gpio.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/gatt.h>
#include <bluetooth/services/nus.h>

#include <string.h>
#include <stdbool.h>

#define DEVICE_NAME     CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

/* -------- BLE ready semaphore -------- */
static K_SEM_DEFINE(ble_ready, 0, 1);

/* Current connection pointer */
static struct bt_conn *current_conn;

/* -------- USB CDC (PuTTY) for optional PC->phone send -------- */
static const struct device *usb_uart = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
static char pc_buf[128];
static size_t pc_len;

/* -------- LED (alias led0 on dongle) -------- */
#define LED_NODE DT_ALIAS(led0)
#if !DT_NODE_HAS_STATUS(LED_NODE, okay)
#error "led0 alias not found in devicetree"
#endif
static const struct gpio_dt_spec led = GPIO_DT_SPEC_GET(LED_NODE, gpios);
static bool blink_enable = false;
static bool led_state = false;
static int64_t next_toggle_ms = 0;

/* Toggle LED helper */
static inline void led_set(bool on)
{
	gpio_pin_set_dt(&led, on);
	led_state = on;
}

/* -------- Connection callbacks -------- */
static void connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		printk("Connect failed (err %u)\n", err);
		return;
	}
	current_conn = bt_conn_ref(conn);
	printk("Connected\n");
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	printk("Disconnected (reason %u)\n", reason);
	if (current_conn) {
		bt_conn_unref(current_conn);
		current_conn = NULL;
	}
	blink_enable = false;
	led_set(false);
}

BT_CONN_CB_DEFINE(conn_cbs) = {
	.connected = connected,
	.disconnected = disconnected,
};

/* -------- NUS RX callback: phone -> dongle -------- */
static void nus_rx_cb(struct bt_conn *conn, const uint8_t *data, uint16_t len)
{
	/* Echo back */
	bt_nus_send(conn, data, len);

	/* Print to USB */
	printk("RX %u bytes: %.*s\n", len, len, (const char *)data);

	/* Simple command parser: "1" = start blink, "0" = stop */
	if (len == 1 && data[0] == '1') {
		blink_enable = true;
		next_toggle_ms = k_uptime_get() + 200;
		printk("Blink ON\n");
	} else if (len == 1 && data[0] == '0') {
		blink_enable = false;
		led_set(false);
		printk("Blink OFF\n");
	}
}

static struct bt_nus_cb nus_cb = {
	.received = nus_rx_cb,
};

/* -------- Advertising data -------- */
static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_NUS_VAL),
};

/* -------- BLE ready callback -------- */
static void bt_ready(int err)
{
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return;
	}

	if (bt_nus_init(&nus_cb)) {
		printk("NUS init failed\n");
		return;
	}

	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
	if (err) {
		printk("Adv start failed (err %d)\n", err);
		return;
	}

	printk("Advertising (connectable) started!\n");
	k_sem_give(&ble_ready);
}

/* -------- Main -------- */
int main(void)
{
	/* LED init */
	if (!device_is_ready(led.port)) {
		printk("LED not ready!\n");
	} else {
		gpio_pin_configure_dt(&led, GPIO_OUTPUT_INACTIVE);
	}

	/* USB UART presence is optional */
	if (!device_is_ready(usb_uart)) {
		printk("usb uart not ready!\n");
	}

	int err = bt_enable(bt_ready);
	if (err) {
		printk("bt_enable failed (err %d)\n", err);
		return 0;
	}

	k_sem_take(&ble_ready, K_FOREVER);

	/* Main loop */
	while (1) {
		/* ---- PC -> Phone (optional) ---- */
		unsigned char c;
		while (uart_poll_in(usb_uart, &c) == 0) {
			if (c == '\r' || c == '\n') {
				if (pc_len && current_conn) {
					bt_nus_send(current_conn, pc_buf, pc_len);
					pc_len = 0;
				}
			} else if (pc_len < sizeof(pc_buf)) {
				pc_buf[pc_len++] = (char)c;
			}
		}

		/* ---- LED blink task ---- */
		if (blink_enable) {
			int64_t now = k_uptime_get();
			if (now >= next_toggle_ms) {
				led_set(!led_state);
				next_toggle_ms = now + 200; /* 200 ms period */
			}
		}

		k_msleep(10);
	}
}
